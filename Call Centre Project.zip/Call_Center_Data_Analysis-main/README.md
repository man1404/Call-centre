# Call_Center_Data_Analysis

## Objective :-
This dashboard (Call Center Data Analysis)is created in PowerBI. The dashboard gives information about No. of Calls Answered, Total Calls, Avg. Satisfaction rate, Call Duration, Avg. Answer speed, Count of Ansewred (Y/N) by Agent, Satisfaction rating by topic and many more. There are two filters first is by month which filters data by the month and the Second is by Agent which filters data by the specific Agent.    

![Screenshot (269)](https://github.com/Kaneriadhruv/Call_Center_Data_Analysis/assets/110617447/6f190f7c-522f-4383-9159-73d71a64baa6)

![Screenshot (272)](https://github.com/Kaneriadhruv/Call_Center_Data_Analysis/assets/110617447/e648104e-1d84-444b-98c0-f701e9f98967)

![Screenshot (270)](https://github.com/Kaneriadhruv/Call_Center_Data_Analysis/assets/110617447/625c67d7-e4f3-46ee-a042-ad358d2cc162)

![Screenshot (271)](https://github.com/Kaneriadhruv/Call_Center_Data_Analysis/assets/110617447/f977794c-c127-424b-8a1c-421ec3f1de5c)

## Project Description :-
Identify the key factor to improve.

Understand the Performance of Every Agent.

Monitoring Satisfaction.

Monthly Report.

## Contact :-
LinkedIn : https://www.linkedin.com/in/dhruv-kaneria-a7440820a

Email : kaneriadhruv@gmail.com
